# -*- coding: utf-8 -*-

import re
from sseapiclient.apiclient import APIClient, RPCResponse

try:
    from sseapiclient._buildinfo import BUILDINFO
except ImportError:
    try:
        from sseape._buildinfo import BUILDINFO
    except ImportError:
        import sseapiclient.buildinfo
        BUILDINFO = sseapiclient.buildinfo.get_buildinfo()


# Remove leading 'v' from version number tag
match = re.match('^v([0-9]+.*$)', BUILDINFO["git_describe"])
if match:
    __version__ = match.group(1)
else:
    __version__ = BUILDINFO["git_describe"] or "unknown"

del match, re
