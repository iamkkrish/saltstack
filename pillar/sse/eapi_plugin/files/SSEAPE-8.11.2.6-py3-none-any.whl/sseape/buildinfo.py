# coding: utf-8

import datetime
import os
import subprocess


def get_buildinfo():
    """
    Return some identifying information about this build of raas-master
    """
    git_describe = "unknown"
    this_dir = os.path.dirname(__file__)
    cmd = ["git", "describe", "--tags", "--dirty", "--always"]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, cwd=this_dir)
        stdout = proc.communicate()[0].strip().decode()
        if proc.returncode == 0:
            git_describe = stdout
    except (OSError, subprocess.SubprocessError):
        pass
    build_date = datetime.datetime.utcnow().isoformat(timespec="seconds")
    return {
        "git_describe": git_describe,
        "build_date": build_date
    }
