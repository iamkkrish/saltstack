# coding: utf-8
'''
VMware CSP utils
'''

# Copyright (C) 2022 VMware, Inc.
#

import json
import logging
import os
import re

# Import 3rd-party libs
import urllib.request
from urllib.error import HTTPError, URLError

HAS_PYJWT = True
try:
    import jwt
except ImportError:
    HAS_PYJWT = False

# Import salt libs
from salt.utils import yaml

import salt

DEFAULT_CSP_URL = "https://console.cloud.vmware.com"


class CSP:
    def __init__(self, csp_base_url: str, csp_api_token: str, logger=None):
        """
        param: csp_base_url: CSP base URL (e.g. staging, production or some other env.), e.g. https://console-stg.cloud.vmware.com
        Initializes the minimum starting point (from env variables) for communicating with CSP
        """
        self.logger = logger or logging.getLogger(__name__)
        self._csp_base_url = csp_base_url
        self._csp_api_token = csp_api_token
        if not HAS_PYJWT:
            raise ImportError('pyjwt library not found. Please install using pip install pyjwt.')

    def get_oauth_apps_in_org(self, csp_access_token: str):
        """
        List all oauth app in the CSP org

        :param csp_access_token: CSP access token
        :return: A collection of oauth apps in the CSP org
        """
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        csp_url = '{}/csp/gateway/am/api/orgs/{}/oauth-apps'.format(self._csp_base_url, org_id)
        response = self._make_request(csp_url, csp_access_token, http_request_method='GET')
        return response

    def add_oauth_app_service_role(self,
                                   csp_access_token: str,
                                   csp_oauth_app_id: str,
                                   csp_service_definition_id: str,
                                   csp_master_role_name: str = None):
        """
        Add oauth app to the org so that the app can have access
        See https://console-stg.cloud.vmware.com/csp/gateway/portal/#/consumer/usermgmt/oauth-apps/view
        :param csp_access_token: CSP access token
        :param csp_oauth_app_id: CSP oauth app ID
        :param csp_service_definition_id:
        :param csp_master_role_name:
        :return: csp master role name
        """
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)

        csp_master_role_name = csp_master_role_name or self._get_csp_master_role_name()
        if not csp_master_role_name:
            raise ValueError('CSP master role name must be set')

        # the only way to make this operation idempotent, delete the app first and then re-add it
        body = {
            'ids': [csp_oauth_app_id]
        }
        csp_url = '{}/csp/gateway/am/api/orgs/{}/clients'.format(self._csp_base_url, org_id)
        response = self._make_request(csp_url, csp_access_token, http_request_method='DELETE', http_request_body=body)

        body = {
            'ids': [csp_oauth_app_id],
            'organizationRoles': [
                {
                    'name': 'org_member'
                }
            ],
            'serviceRoles': [
                {
                    'serviceRoleNames': [],
                    'serviceRoles': [
                        {
                            'name': csp_master_role_name,
                        }
                    ],
                    'serviceDefinitionId': csp_service_definition_id
                }
            ]
        }
        csp_url = '{}/csp/gateway/am/api/orgs/{}/clients'.format(self._csp_base_url, org_id)
        response = self._make_request(csp_url, csp_access_token, http_request_method='POST', http_request_body=body)
        return csp_master_role_name

    def create_agent_oauth_app(self,
                               csp_access_token: str,
                               csp_service_definition_id: str,
                               csp_oauth_app_name: str = None,
                               csp_oauth_app_description: str = None,
                               csp_master_role_name: str = None):
        """
        Create an oauth app in the CSP org
        See https://confluence.eng.vmware.com/display/SBUS/OAuth+App+and+User+API+Token+flow#OAuthAppandUserAPITokenflow-CreateanOAuthappintheCSPconsole
        :param csp_access_token: CSP access token
        :param csp_service_definition_id:  CSP SSC service definition ID (varies depending on environment)
        :param csp_oauth_app_name: optional oauth app name; if not explicitly specified, deafult config value from master config file will be used
        :param csp_oauth_app_description: optional oauth app name; if not explicitly specified, default config value from master config file will be used
        :param csp_master_role_name: CSP master role name
        :return: An object that is the created oauth app
        """
        csp_oauth_app_display_name = csp_oauth_app_name or self._get_oauth_app_name()
        if not csp_oauth_app_display_name:
            raise ValueError('oauth app name must be set')

        csp_oauth_app_display_description = csp_oauth_app_description or self._get_oauth_app_description()
        if not csp_oauth_app_display_description:
            raise ValueError('oauth app description must be set')

        csp_master_role_name = csp_master_role_name or self._get_csp_master_role_name()
        if not csp_master_role_name:
            raise ValueError('CSP master role name must be set')

        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        csp_url = '{}/csp/gateway/am/api/orgs/{}/oauth-apps'.format(self._csp_base_url, org_id)
        data = {
            'displayName': csp_oauth_app_display_name,
            'description': csp_oauth_app_display_description,
            'grantTypes': [
                'client_credentials'
            ],
            'allowedScopes': {
                'servicesScopes': [
                    {
                        'roles': [
                            {
                                'name': csp_master_role_name,
                            }
                        ],
                        # see https://confluence.eng.vmware.com/display/CAEng/WorkStream%3A+SSC+Onboarding+With+CSP
                        'serviceDefinitionId': csp_service_definition_id
                    }
                ],
                'organizationScopes': {
                    'allRoles': False,
                    'roleNames': [
                        'org_member'
                    ],
                    'permissions': [],
                    'allPermissions': False,
                    'keptInToken': [
                        'ROLES'
                    ]
                },
                'generalScopes': []
            }
        }

        response = self._make_request(csp_url, csp_access_token, http_request_method='POST', http_request_body=data)
        return response

    def delete_agent_oauth_app(self,
                               csp_access_token: str,
                               oauth_app_id: str):
        """
        Delete OAuth app
        :param csp_access_token: CSP access token
        :param oauth_app_id: CSP org oauth app id
        :return:
        """
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        body = {
            "clientIdsToDelete": [oauth_app_id]
        }
        csp_url = '{}/csp/gateway/am/api/orgs/{}/oauth-apps'.format(self._csp_base_url, org_id)

        response = self._make_request(csp_url, csp_access_token, http_request_method='DELETE', http_request_body=body)
        return response

    def recreate_agent_oauth_app_secret(self,
                                        csp_access_token: str,
                                        oauth_app_id: str):
        """
        Update secret (client id, client secret) of the oauth app
        :param csp_access_token: CSP access token
        :param oauth_app_id: CSP org oauth app id
        :return: new secret (client id, client, secret)
        """
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        csp_url = '{}/csp/gateway/am/api/orgs/{}/oauth-apps/{}/secret'.format(self._csp_base_url, org_id, oauth_app_id)

        response = self._make_request(csp_url, csp_access_token, http_request_method='PUT')
        return response

    def get_csp_ssc_service_definition_id(self, csp_access_token: str, ssc_well_known_service_name_pattern: str = None) -> str:
        """
        Get service definition id
        Consider a simpler implementation of this method
        :param csp_access_token: CSP access token
        :param ssc_well_known_service_name_pattern: well-known CSP ssc service name pattern/regex, e.g. ".*Config$"
        :return:
        """
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        csp_ssc_well_known_service_name_pattern = ssc_well_known_service_name_pattern or \
                                                  self._get_csp_ssc_well_known_service_name_pattern()

        # get the details of the org from org id
        csp_url = '{}/csp/gateway/slc/api/v2/orgs/{}/services'.format(self._csp_base_url, org_id)
        response = self._make_request(csp_url, csp_access_token, http_request_method='GET')

        service_definition_id = None
        # We do not expect many results because we are filtering by customer org, but let's page anyway
        for org in response['results']:
            for service in org['services']:
                if re.fullmatch(csp_ssc_well_known_service_name_pattern, service['name']):
                    # get service definition id from the self-link
                    service_definition_id = service['documentSelfLink'].rsplit('/', 1)[-1]
                    break

        if not service_definition_id:
            raise ValueError('Service not found for service name pattern [{}]'.format(csp_ssc_well_known_service_name_pattern))

        return service_definition_id

    def get_oauth_app_by_name(self,
                              csp_access_token: str,
                              csp_service_definition_id: str,
                              csp_oauth_app_name: str = None,
                              csp_master_role_name: str = None) -> str:
        """
        Use the limited oauth search API to the best of our ability. Find the first matching oauth app
        :param csp_access_token:
        :param csp_service_definition_id:
        :param csp_oauth_app_name: CSP auth app name to find
        :param csp_master_role_name: CSP role name, e.g. "saltstack:master"
        :return: oauth app if found or None if not found
        """
        csp_oauth_app_name = csp_oauth_app_name or self._get_oauth_app_name()
        if not csp_oauth_app_name:
            raise ValueError("oauth app name must be set")

        csp_master_role_name = csp_master_role_name or self._get_csp_master_role_name()
        if not csp_master_role_name:
            raise ValueError("CSP master role name must be set")

        # see doc on our (limited) capabilities regarding search:
        # https://console.cloud.vmware.com/csp/gateway/am/api/swagger-ui.html#/Organization%20Managed%20OAuth%20Apps%20(Clients)/searchOrganizationClientsByRoleNamesUsingPOST
        # it's easier to just get all oauth apps scoped to an org and filter by name
        org_id = self.get_org_id_from_csp_access_token(csp_access_token)
        pageLimit = 15  # max allowed for this API
        csp_url = '{}/csp/gateway/am/api/orgs/{}/oauth-apps?pageLimit={}'.format(self._csp_base_url, org_id, pageLimit)

        response = self._make_request(csp_url,
                                      csp_access_token,
                                      http_request_method='GET')

        result = None
        while True:
            next_link = response['nextLink']
            # iterate over one page
            for oauth_app in response['results']:
                if oauth_app['displayName'] == csp_oauth_app_name:
                    result = oauth_app
                    self.logger.debug('Matching oauth app found: [%s]', result)
                    break

            # if we have more page to look at, fetch the next page
            if not result and next_link:
                csp_url = '{}{}'.format(self._csp_base_url, next_link)
                response = self._make_request(csp_url,
                                              csp_access_token,
                                              http_request_method='GET')
            else:
                # we are done; terminate the loop
                break

        return result

    def get_auth_token_from_api_token(self, csp_api_token: str = None) -> str:
        """
        Exchange API token for auth token as per
        https://docs.vmware.com/en/VMware-Cloud-services/services/Using-VMware-Cloud-Services/GUID-E2A3B1C1-E9AD-4B00-A6B6-88D31FCDDF7C.html
        :return: access_token
        """
        csp_api_token = csp_api_token or self._csp_api_token
        data = 'api_token={}'.format(csp_api_token)
        csp_url = '{}/csp/gateway/am/api/auth/api-tokens/authorize'.format(self._csp_base_url)
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json',
        }

        response = self._make_request(csp_url, http_request_method='POST', http_request_body=data, http_headers=headers)
        access_token = response['access_token']
        return access_token

    def validate_access_token(self, csp_access_token: str):
        """
        Validate access token, e.g. assert required CSP roles
        We expect 'csp:org_owner' or 'csp:org_admin' role(s)
        :param csp_access_token: access token to validate
        :return:
        """
        decoded_token = jwt.decode(csp_access_token, options={'verify_signature': False})
        CSP_REQUIRED_ROLES = [
            'csp:org_owner',
            'csp:org_admin',
        ]
        acceptable_roles = [role for role in CSP_REQUIRED_ROLES if role in decoded_token['perms']]
        if not acceptable_roles:
            raise ValueError(
                'CSP access token must have at least one of the following roles: [{}]'.format(CSP_REQUIRED_ROLES))

    def create_update_csp_pillar(self,
                                 csp_client_id: str,
                                 csp_client_secret: str,
                                 csp_org_id: str,
                                 csp_pillar_env='base',
                                 csp_pillar_name=None):
        """
        Creates or updates pillar ```csp.sls``` with csp org secrets
        :param csp_org_id: CSP org id
        :param csp_pillar_name: pillar name
        :param csp_pillar_env: pillar env name, e.g. 'base'
        :param csp_client_id: CSP client ID (comes from an oauth app)
        :param csp_client_secret: CSP client secret (comes from an oauth app)
        :return: a tuple of pillar name, CSP pillar contents (dict)
        """

        # create/update top pillar
        pillar_env_dir = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')).get('pillar_roots')
        if not pillar_env_dir:
            raise ValueError('"pillar_roots" key must be set in master config file')
        pillar_env_dir = pillar_env_dir[csp_pillar_env][0]
        csp_pillar_name = csp_pillar_name or self._get_csp_pillar_name()

        self.logger.debug('Creating or updating CSP pillar [%s] in [%s]', csp_pillar_name, pillar_env_dir)

        # we should be careful with the contents of the top file
        # update it but do not overwrite it
        config_file = os.path.join(pillar_env_dir, 'top.sls')

        # /srv/pillar/top.sls should look something like this at the bare minimum, pointing at the 'csp' pillar
        # {pillar_env}:
        #    '*':
        #        - csp
        self._update_config_file(config_file,
                                 {csp_pillar_env: {
                                     '*': ['csp']
                                 }})

        # (re)create csp pillar with these four keys
        # it is safe to just override the contents of the csp.sls pillar file
        config_file = os.path.join(pillar_env_dir, 'csp.sls')
        result = self._update_config_file(config_file,
                                          {
                                              csp_pillar_name: {
                                                  'csp_url': self._csp_base_url,
                                                  'csp_org_id': csp_org_id,
                                                  'csp_client_id': csp_client_id,
                                                  'csp_client_secret': csp_client_secret
                                              }
                                          },
                                          override_file=True)

        return csp_pillar_name, result[csp_pillar_name]

    def update_master_csp_conf(self, csp_pillar_name: str = None, csp_pillar_env: str = 'base'):
        """
            Updates master config file with a pointer to the pillar, identified by ```sseapi_csp_pillar```
            :param csp_pillar_name: pillar name
            :param csp_pillar_env: pillar env
            :return: resulting dict of master config
            """
        self.logger.debug('Updating master config file with csp pillar info.')
        csp_pillar_name = csp_pillar_name or self._get_csp_pillar_name()
        default_include_pattern = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')).get(
            "default_include")
        if not default_include_pattern:
            raise ValueError("'default_include' key must be set in master config file")

        config_file = os.path.join(salt.syspaths.CONFIG_DIR, os.path.dirname(default_include_pattern), 'csp.conf')

        # create config in /etc/salt/master.d/csp.conf with pointer to the pillar
        # sseapi_csp_pillar = <pilar_name> (default: CSP_AUTH_TOKEN)
        # sseapi_csp_pillar_env = <pillar_env>
        self._update_config_file(config_file, {
            'sseapi_csp_pillar': csp_pillar_name,
            'sseapi_csp_pillar_env': csp_pillar_env
        })

        return salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master'))

    def update_cloud_conf(self, sseapi_server: str):
        """
            Updates cloud.conf config file with a pointer to ```sseapi_server```
            :param sseapi_server: ssc server
            """
        self.logger.debug('Updating cloud.conf file with sseapi_server info.')
        if not sseapi_server:
            raise ValueError("'sseapi_server' must be set")

        default_include_pattern = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')).get(
            "default_include")
        if not default_include_pattern:
            raise ValueError("'default_include' key must be set in master config file")

        config_file = os.path.join(salt.syspaths.CONFIG_DIR, os.path.dirname(default_include_pattern), 'cloud.conf')

        # create config in /etc/salt/master.d/cloud.conf
        result = self._update_config_file(
            config_file, {
                'sseapi_server': sseapi_server
            })

        return result

    def get_org_id_from_csp_access_token(self, csp_access_token: str):
        """
        Get org id from CSP access token in JWT format
        :param csp_access_token: CSP access/JWT token
        :return: CSP org id
        """
        if not csp_access_token:
            raise ValueError("CSP access token must be set")

        ret = jwt.decode(csp_access_token, options={'verify_signature': False})

        return ret['context_name']

    def _make_request(self, csp_url: str,
                      csp_access_token: str = None,
                      http_request_method: str = 'GET',
                      http_headers: dict = None,
                      http_request_body: str = None):

        http_headers = http_headers or {
            'Content-Type': 'application/json',
            'csp-auth-token': csp_access_token
        }

        try:
            self.logger.debug('Calling CSP API [%s] [%s] with body [%s]', http_request_method, csp_url,
                              http_request_body)
            if http_request_body:
                if isinstance(http_request_body, dict):
                    http_request_body = json.dumps(http_request_body)
                http_request_body = http_request_body.encode('utf-8')

            request = urllib.request.Request(csp_url,
                                             method=http_request_method,
                                             data=http_request_body,
                                             headers=http_headers)
            with urllib.request.urlopen(request) as f:
                response_body = f.read()
                response = None
                if response_body:
                    response = json.loads(response_body)
            self.logger.debug('Response from CSP: [%s]', response)
            return response
        except (HTTPError, URLError) as e:
            self.logger.exception('Exception in request [%s]: %s. Body: %s', csp_url, e,
                                  e.file.fp.read() if e.file.fp else None)
            raise

    def _get_validate_env(self):
        """
        Validates presence of the minimum set of environment variables to start communicating with CSP
        :return: CSP_API_TOKEN (previously known as "refresh token")
        """
        csp_api_token_key_name = 'CSP_API_TOKEN'
        csp_api_token = os.getenv(csp_api_token_key_name)
        if not csp_api_token:
            raise ValueError('"{}" must be set'.format(csp_api_token_key_name))

        return csp_api_token

    def _get_oauth_app_name(self):
        """
        Return the well-known oauth app name, scoped to the master
        :return:
        """
        master_opts = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master'))
        master_id = master_opts.get('id')
        oauth_app_display_name = master_opts.get('csp_oauth_app_name',
                                                 'Salt Master App for master id:{}'.format(master_id))
        return oauth_app_display_name

    def _get_oauth_app_description(self):
        """
        Return the well-known oauth app description, scoped to the master
        :return:
        """
        oauth_app_display_description = '{} (created by {})'.format(self._get_oauth_app_name(), 'sseapi-config')
        return oauth_app_display_description

    def _get_csp_pillar_name(self):
        csp_pillar_name = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')) \
            .get('sseapi_csp_pillar', 'CSP_AUTH_TOKEN')
        return csp_pillar_name

    def _get_csp_ssc_well_known_service_name_pattern(self):
        """
        CSP service was originally named "SaltStack Config" and later renamed to "Aria Automation Config",
        with a few short variants floating around such as "Aria Config" or just "Config"
        :return:
        """
        csp_ssc_well_known_service_name_pattern = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')) \
            .get('csp_ssc_well_known_service_name_pattern', '.*Config$')
        return csp_ssc_well_known_service_name_pattern

    def _get_csp_master_role_name(self):
        """
        Return the well-known saltstack:master role name
        :return:
        """
        csp_master_role_name = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master')) \
            .get('csp_master_role_name', 'saltstack:master')
        return csp_master_role_name

    def _update_config_file(self, config_file: str, config_update: dict, override_file: bool = False):
        """
        Update/create config file with
        :param config_file: file to create/update
        :param config: key/value config settings to set
        :param override_file: override the file without preserving any existing config in it
        :return: resulting config
        """
        config = {}
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
        if not override_file:
            if os.path.exists(config_file) and os.path.getsize(config_file) > 0:
                with os.fdopen(os.open(config_file, os.O_RDONLY), 'r') as fp:
                    config = yaml.safe_load(fp)

        config.update(config_update)

        with os.fdopen(os.open(config_file, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600), 'w') as fp:
            data = yaml.safe_dump(config, default_flow_style=False)
            fp.write(data)

        return config
