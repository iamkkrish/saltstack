# -*- coding: utf-8 -*-

"""
Decorators to validate security or connection access before method execution
"""
import functools
import logging

import sseape
import sseape.utils.client


def is_connected_to_ssc(func):
    """
    Validate connectivity to Saltstack Config instance
    Return failure, if it cannot otherwise continue with execution
    """

    @functools.wraps(func)
    def wrapper_is_connected_to_ssc(**kwargs):
        """
        Get raas client -> fetch version resource -> print response

        Usage:
            @is_connected_to_ssc
            def update_configuration(opts, pillar):
                ...
                ...
        """
        logger = kwargs.get('logger') or logging.getLogger(__name__)
        try:
            raas_client = sseape.utils.client.make_http_client(opts=kwargs.get('opts'),
                                                               pillar=kwargs.get('pillar'))

            # Assumption: If used during cloud integration, then the http client would make use of
            # auth token retrieved from cloud services such as CSP. Retrying one more time to handle any transient
            # race condition
            logger.info('Validating connectivity to SaltStack Cloud instance [%s]', raas_client.server)
            app_version = '/app-version.json'
            response = raas_client.fetch(app_version, method='GET', retry_on_auth_failure=True)
            if not isinstance(response, dict):
                raise ValueError('Unexpected response from {}{}. Response: {}'.format(
                    raas_client.server,
                    app_version,
                    response))
            logger.info('Successfully validated connectivity to SaltStack Cloud instance [%s]. Response: %s',
                        raas_client.server,
                        str(response))
            return func(**kwargs)
        except Exception as ex:
            logger.error("Failed to validate connectivity to SaltStack instance [%s]. Exception "
                         "validating response: [%s]",
                         raas_client.server,
                         str(ex))
            raise

    return wrapper_is_connected_to_ssc
