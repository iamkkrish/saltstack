# -*- coding: utf-8 -*-
'''
The RAAS Returner
'''

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
from __future__ import absolute_import, unicode_literals
import base64
import copy
import datetime
import logging
import random
import sys
import uuid

# Import Salt libs
import salt.serializers.msgpack
import salt.utils.jid
from salt.exceptions import CommandExecutionError
from salt.serializers import DeserializationError, SerializationError

# Import 3rd-party libs
from sseapiclient.exc import NotConnectable, RPCError

# Import SSEAPE libs
import sseape.utils.config as sseape_config
import sseape.utils.json
from sseape.utils.client import make_api_client, get_pillar

log = logging.getLogger(__name__)

__virtualname__ = 'sseapi'

BASE64_PREFIX = 'b64:'
DATE_PREFIX = 'date:'
DATETIME_PREFIX = 'datetime:'
LONGINT_PREFIX = 'longint:'
UUID_PREFIX = 'uuid:'


def __virtual__():
    if '__role' not in __opts__:
        return False, 'Unable to find out the role(master or minion)'
    if __opts__['__role'] not in ('master', 'syndic'):
        return (False,
                'The SSEApi returner is meant to run on the salt-master, '
                'not on {0}'.format(__opts__['__role']))
    return True


def _event_queue_enabled(strategy):
    '''
    Check if event queue is enabled in the config
    '''
    ret = False
    if (sseape_config.get(__opts__, 'sseapi_event_queue.strategy') == strategy and
        'sseapi_local_queue.push' in __salt__):
        ret = True
    return ret


def _send_events_to_queue(events):
    '''
    Push events onto the queue
    '''
    queue = sseape_config.get(__opts__, 'sseapi_event_queue.name')
    try:
        items = [{'data': event} for event in events]
        __salt__['sseapi_local_queue.push'](queue=queue, items=items)
    except CommandExecutionError as exc:
        log.error('Error writing events to local sqlite-backed queue: %s', str(exc))


def _rpc_queue_enabled(strategy):
    '''
    Check if RPC queue is enabled in the config
    '''
    ret = False
    if (sseape_config.get(__opts__, 'sseapi_rpc_queue.strategy') == strategy and
        'sseapi_local_queue.push' in __salt__):
        ret = True
    return ret


def _send_rpc_to_queue(payload):
    '''
    Push an RPC payload onto the queue
    '''
    queue = sseape_config.get(__opts__, 'sseapi_rpc_queue.name')
    try:
        items = [{'data': payload}]
        __salt__['sseapi_local_queue.push'](queue=queue, items=items)
    except CommandExecutionError as exc:
        log.error('Error writing RPC payload to queue: %s', str(exc))


def _gen_jid(passed_jid):
    if passed_jid is not None:
        return passed_jid
    # Generate a JID
    try:
        jid = salt.utils.jid.gen_jid(__opts__)  # pylint: disable=too-many-function-args
    except TypeError:
        jid = salt.utils.jid.gen_jid()  # pylint: disable=no-value-for-parameter
    # Return the same JID with randomized microseconds
    return '{0}{1:06d}'.format(jid[:-6], random.randint(0, 999999))


def _encode_binary_fields(obj):
    '''
    Encode binary fields in a serializer-friendly way in an otherwise
    serializable object
    '''
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            key2 = _encode_binary_fields(key)
            value2 = _encode_binary_fields(obj[key])
            if key2 != key:
                obj.pop(key)
                obj[key2] = value2
            elif value2 != obj[key]:
                obj[key] = value2
        return obj
    if isinstance(obj, list):
        for (idx, item) in enumerate(obj):
            item2 = _encode_binary_fields(item)
            if item2 != item:
                obj[idx] = item2
        return obj
    if isinstance(obj, bytes):
        return BASE64_PREFIX + base64.b64encode(obj).decode()
    # Order is important here: datetime.datetime is a subclass of datetime.date
    if isinstance(obj, datetime.datetime):
        return DATETIME_PREFIX + obj.isoformat()
    if isinstance(obj, datetime.date):
        return DATE_PREFIX + obj.isoformat()
    if isinstance(obj, int) and not -sys.maxsize <= obj <= sys.maxsize:
        return LONGINT_PREFIX + str(obj)
    if isinstance(obj, uuid.UUID):
        return UUID_PREFIX + str(obj)
    return obj


def _decode_binary_fields(obj):
    '''
    Undo the effects of _encode_binary_fields()
    '''
    if isinstance(obj, (set, tuple)):
        obj = list(obj)
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            key2 = _decode_binary_fields(key)
            value2 = _decode_binary_fields(obj[key])
            if key2 != key:
                obj.pop(key)
                obj[key2] = value2
            elif value2 != obj[key]:
                obj[key] = value2
    elif isinstance(obj, list):
        for (idx, item) in enumerate(obj):
            item2 = _decode_binary_fields(item)
            if item2 != item:
                obj[idx] = item2
    elif isinstance(obj, str):
        # pylint: disable=unnecessary-lambda
        CONV = {
            BASE64_PREFIX: lambda obj: base64.b64decode(obj),
            LONGINT_PREFIX: lambda obj: int(obj),
            DATE_PREFIX: lambda obj: datetime.date.fromisoformat(obj),
            DATETIME_PREFIX: lambda obj: datetime.datetime.fromisoformat(obj),
            UUID_PREFIX: lambda obj: uuid.UUID(obj),
        }
        for (prefix, fn) in CONV.items():
            if obj.startswith(prefix):
                try:
                    obj = fn(obj[len(prefix):])
                except (AttributeError, TypeError, ValueError):
                    pass
                break
    return obj


def get_client():
    if 'sseapi_client' not in __context__:
        pillar = get_pillar(opts=__opts__, mods=__salt__)
        __context__['sseapi_client'] = make_api_client(opts=__opts__, pillar=pillar)
    return __context__['sseapi_client']


def returner(ret):
    '''
    Return a job to the SSEApi server
    '''
    pass  # pylint: disable=unnecessary-pass


def save_load(jid, load, minions=None):
    '''
    Save the pub load
    '''
    cache_value = None
    cache_key = '{}/{}'.format(__opts__['id'], jid)

    try:
        cache_value = __salt__['sseapi_local_cache.get'](cache='load', key=cache_key)
    except KeyError:
        log.trace('Local load cache not available')
    except (CommandExecutionError, DeserializationError) as exc:
        log.trace('Load for %s not found in local cache: %s', cache_key, str(exc))

    if not cache_value:
        load2 = copy.deepcopy(load)
        _encode_binary_fields(load2)
        json_limit = sseape_config.get(__opts__, 'sseapi_json_payload_limit')
        if json_limit:
            load2_pruned = sseape.utils.json.size_limited(load2, limit=max(json_limit, 100))
            if load2_pruned != load2:
                log.warning('Load for jid %s pruned due to configured sseapi_json_payload_limit', jid)
                load2 = load2_pruned

        if _rpc_queue_enabled('always'):
            payload = {
                'resource': 'ret',
                'method': 'save_load',
                'kwargs': {
                    'master_id': __opts__['id'],
                    'jid': jid,
                    'load': load2
                }
            }
            _send_rpc_to_queue(payload)
        else:
            try:
                get_client().api.ret.save_load(__opts__['id'], jid, load=load2)
            except (NotConnectable, RPCError) as exc:
                log.error('Failed to save load: %s', exc)
                log.debug('Load which failed to be saved: %r', load)

        try:
            value = salt.serializers.msgpack.serialize(load2)  # pylint: disable=assignment-from-no-return
            __salt__['sseapi_local_cache.set'](cache='load', key=cache_key, value=value)
        except KeyError:
            pass
        except (CommandExecutionError, SerializationError) as exc:
            log.error('Failed to save load %s to local cache: %s', cache_key, str(exc))
    else:
        log.trace('Key %s already in cache, dropping record', cache_key)


def get_jid(jid):
    '''
    Return information about the given jid
    '''
    try:
        return get_client().api.ret.get_jid(str(jid), master_id=__opts__['id']).ret
    except (NotConnectable, RPCError) as exc:
        log.error('Failed to get JID: %s', exc, exc_info_on_loglevel=logging.DEBUG)


def get_load(jid):
    '''
    Return information about the given jid
    '''
    load = None
    try:
        key = '{}/{}'.format(__opts__['id'], jid)
        value = __salt__['sseapi_local_cache.get'](cache='load', key=key)
        load = salt.serializers.msgpack.deserialize(value)  # pylint: disable=assignment-from-no-return
        if load:
            log.info('Returning load %s from local cache', key)
        else:
            log.info('No load %s found in local cache', key)
    except KeyError:
        log.trace('Local load cache not available')
    except (CommandExecutionError, DeserializationError) as exc:
        log.info('Failed to get load %s from local cache: %s', key, str(exc))

    if not load:
        try:
            load = get_client().api.ret.get_load(__opts__['id'], str(jid)).ret
        except (NotConnectable, RPCError) as exc:
            log.error('Failed to get load: %s', exc, exc_info_on_loglevel=logging.DEBUG)

    if load:
        load = _decode_binary_fields(load)
    return load


def get_fun(fun):
    '''
    Return a dict of the named func being called on all minions
    '''
    try:
        return get_client().api.ret.get_fun(fun).ret
    except (NotConnectable, RPCError) as exc:
        log.error('Failed to get fun: %s', exc, exc_info_on_loglevel=logging.DEBUG)


def get_jids():
    '''
    return a list of jids
    '''

    try:
        ret = get_client().api.ret.get_jids().ret
        for jid, load in ret.items():
            ret[jid] = salt.utils.jid.format_jid_instance(jid, load)
        return ret
    except (NotConnectable, RPCError) as exc:
        log.error('Failed to get JIDs: %s', exc, exc_info_on_loglevel=logging.DEBUG)
    return {}


def get_minions():
    '''
    Return a list of minions
    '''
    try:
        return get_client().api.ret.get_minions().ret
    except (NotConnectable, RPCError) as exc:
        log.error('Failed to get minions: %s', exc, exc_info_on_loglevel=logging.DEBUG)


def event_return(events):
    '''
    Send a list of events up to RAAS!
    '''
    json_limit = sseape_config.get(__opts__, 'sseapi_json_payload_limit')
    if json_limit:
        for (idx, event) in enumerate(events):
            event_pruned = sseape.utils.json.size_limited(event, limit=max(json_limit, 100))
            if event_pruned != event:
                log.warning('Event %s pruned due to configured sseapi_json_payload_limit', event.get('tag', '(unknown)'))
                events[idx] = event_pruned

    for event in events:
        _encode_binary_fields(event)
        event['data'].setdefault('_master_path', []).append(__opts__['id'])

    if _event_queue_enabled('always'):
        _send_events_to_queue(events)
    else:
        try:
            get_client().api.ret.save_event(__opts__['id'], events)
        except (NotConnectable, RPCError) as exc:
            log.error('Failed to save events: %s', exc, exc_info_on_loglevel=logging.DEBUG)
            if _event_queue_enabled('on_failure'):
                _send_events_to_queue(events)


def prep_jid(nocache=False, passed_jid=None):  # pylint: disable=unused-argument
    '''
    Do any work necessary to prepare a JID, including sending a custom jid
    '''
    return _gen_jid(passed_jid)


def clean_old_jobs():
    '''
    Called in the master's event loop to purge old job history data. This is a
    no-op for SSE since old job cleanup is implemented in raas.
    '''
