# -*- coding: utf-8 -*-
'''
    sseape.scripts
    ~~~~~~~~~~~~~~

    This will print out example configuration
'''

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/

# Import Python libs
import argparse
import logging
import os
import sys

import sseape.utils.config as sseape_config
import sseape.version
from sseape.utils.access import is_connected_to_ssc
from sseape.utils.csp import CSP, DEFAULT_CSP_URL


class ShowVersion(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        print('SSEAPE version {git_describe} {build_date}'.format(**sseape.version.BUILDINFO))
        sys.exit(0)


class JoinSSC():
    """
    Workflow to join this master to SSC Cloud instance
    Creates the necessary CSP constructs, creates pillar with CSP secret that can be used by master to talk to
    the raas instance in the cloud
    """

    # class-level variable contains master config opts
    MASTER_OPTS = {}
    # class-level variable contains CSP pillar opts
    CSP_PILLAR_OPTS = {}

    logger = logging.getLogger(__name__)

    @staticmethod
    def run(csp_base_url: str, log_level: str = 'INFO', override_oauth_app: bool = False, **kwargs):
        JoinSSC._configure_logger(logging.getLogger(__name__), log_level)

        JoinSSC.logger.info('SSEAPE joining SSC Cloud... %s %s',
                            sseape.version.BUILDINFO['git_describe'],
                            sseape.version.BUILDINFO['build_date'])
        csp_api_token = JoinSSC.get_validate_env()
        csp = CSP(csp_base_url, csp_api_token, logger=JoinSSC.logger)

        # grab the prerequisites for communicating with CSP
        JoinSSC.logger.info('Retrieving CSP auth token.')
        csp_access_token = csp.get_auth_token_from_api_token()
        csp.validate_access_token(csp_access_token)
        csp_org_id = csp.get_org_id_from_csp_access_token(csp_access_token)

        csp_service_definition_id = csp.get_csp_ssc_service_definition_id(csp_access_token)

        # create/update service app
        oauth_app = csp.get_oauth_app_by_name(csp_access_token, csp_service_definition_id)
        if oauth_app:
            if override_oauth_app:
                JoinSSC.logger.info('Deleting oauth app [%s] with id [%s] and recreating it.',
                                    oauth_app['displayName'],
                                    oauth_app['id'])
                csp.delete_agent_oauth_app(csp_access_token, oauth_app['id'])
                oauth_app_secret = csp.create_agent_oauth_app(csp_access_token, csp_service_definition_id)
                oauth_app = csp.get_oauth_app_by_name(csp_access_token, csp_service_definition_id)
            else:
                JoinSSC.logger.info('Updating oauth app [%s] with new secret.', oauth_app['displayName'])
                oauth_app_secret = csp.recreate_agent_oauth_app_secret(csp_access_token, oauth_app['id'])
        else:
            JoinSSC.logger.info('Creating new oauth app.')
            oauth_app_secret = csp.create_agent_oauth_app(csp_access_token, csp_service_definition_id)
            oauth_app = csp.get_oauth_app_by_name(csp_access_token, csp_service_definition_id)

        csp_client_id = oauth_app_secret['clientId']
        csp_client_secret = oauth_app_secret['clientSecret']
        JoinSSC.logger.info('Finished with oauth app [%s] in org [%s].', oauth_app['displayName'], csp_org_id)

        # create/update service role
        role_name = csp.add_oauth_app_service_role(csp_access_token, csp_client_id, csp_service_definition_id)
        JoinSSC.logger.info('Added service role [%s] for oauth app [%s].', role_name, oauth_app['displayName'])

        # create/update pillar with secrets
        pillar_name, JoinSSC.CSP_PILLAR_OPTS = csp.create_update_csp_pillar(csp_client_id,
                                                               csp_client_secret,
                                                               csp_org_id)
        JoinSSC.logger.info('Created pillar [%s].', pillar_name)

        # update master config to point to pillar
        JoinSSC.MASTER_OPTS = csp.update_master_csp_conf()
        JoinSSC.MASTER_OPTS.update(kwargs)
        JoinSSC.logger.info('Updated master config. Please restart master for config changes to take effect.')

        # update cloud.conf to point to the SSC instance
        csp.update_cloud_conf(sseapi_server=JoinSSC.MASTER_OPTS.get('sseapi_server'))
        JoinSSC.logger.info('Updated master cloud.conf.')

        # complete joining SaltStack Cloud instance
        JoinSSC.validate_and_complete_join_saltstack_instance(opts=JoinSSC.MASTER_OPTS,
                                                              pillar=JoinSSC.CSP_PILLAR_OPTS,
                                                              logger=JoinSSC.logger)

    @staticmethod
    def get_validate_env():
        """
        Validates presence of the minimum set of environment variables to start communicating with CSP
        :return: CSP_API_TOKEN (previously known as "refresh token")
        """
        csp_api_token_key_name = 'CSP_API_TOKEN'
        csp_api_token = os.getenv(csp_api_token_key_name)
        if not csp_api_token:
            raise ValueError('"{}" must be set'.format(csp_api_token_key_name))

        return csp_api_token

    @staticmethod
    @is_connected_to_ssc
    def validate_and_complete_join_saltstack_instance(**kwargs):
        """
        Validate connectivity to SSC instance and log completion of join operation, if successful
        """
        JoinSSC.logger.info('Finished SSEAPE joining SSC Cloud... %s %s',
                            sseape.version.BUILDINFO['git_describe'],
                            sseape.version.BUILDINFO['build_date'])

    @staticmethod
    def _configure_logger(logger, log_level):
        """
        Configure logger with configuration suitable for workflow execution by this class
        :param logger:
        :return:
        """
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(log_level)
        formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
        handler.setFormatter(formatter)
        logger.addHandler(handler)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--ext-modules',
        action='store_true',
        default=False,
        help='Print out the external extension modules directories settings')
    parser.add_argument(
        '--default-config',
        action='store_true',
        default=False,
        help='Print out the default configuration settings')
    parser.add_argument(
        '--all',
        action='store_true',
        default=False,
        help='This is the same as passing --ext-modules and --default-config')
    parser.add_argument(
        '--fileserver-update-interval',
        action='store',
        type=int,
        dest='fileserver_update_interval',
        default=60)
    parser.add_argument(
        '--timeout',
        action='store',
        type=int,
        dest='timeout',
        default=15)
    parser.add_argument(
        '-l',
        '--log-level',
        action='store',
        dest='log_level',
        default='INFO',
        type=str.upper,
        help='log level for python logger')
    parser.add_argument(
        '--version',
        nargs=0,
        action=ShowVersion)

    sub_parsers = parser.add_subparsers(dest='command')
    parser_join = sub_parsers.add_parser('join',
                                         help='Join this salt-master to the SaltStack Cloud instance')
    parser_join.add_argument('--ssc-url',
                             action='store',
                             dest='ssc_url',
                             default='http://localhost:8080',
                             help='SaltStack Cloud instance region-specific URL')
    parser_join.add_argument('--csp-url',
                             action='store',
                             default=DEFAULT_CSP_URL,  # prod
                             dest='csp_url',
                             help='VMware Cloud Services Portal (CSP) URL')
    parser_join.add_argument('--override-oauth-app',
                             action='store_true',
                             default=False,
                             dest='override_oauth_app',
                             help='Recreate OAuth app for this master if OAuth already exists.')

    args = parser.parse_args()
    default_override = {
        'ext_modules': args.ext_modules or args.all,
        'default_config': args.default_config or args.all,
        'fs_update_interval': args.fileserver_update_interval,
        'sseapi_pubkey_path': lambda master_opts: os.path.join(master_opts['pki_dir'], 'sseapi_key.pub'),
        'timeout': args.timeout,
    }

    if args.command == 'join':
        default_override['sseapi_server'] = args.ssc_url
        JoinSSC.run(csp_base_url=args.csp_url,
                    log_level=args.log_level,
                    override_oauth_app=args.override_oauth_app,
                    **default_override)
    else:
        print(sseape_config.generate(**default_override))
    parser.exit(0)
