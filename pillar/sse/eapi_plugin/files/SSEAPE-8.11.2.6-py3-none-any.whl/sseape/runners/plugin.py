# coding: utf-8
"""
Salt-Master SSE Plugin Upgrade runner
"""
import logging

from sseape.utils.plugin import MasterPluginManager

log = logging.getLogger(__name__)


def update():
    """
    Runner to update salt master plugin.
    """
    log.info("Updating salt-master plugin. JID: [%s]", __jid__)  # pylint: disable=E0602
    return MasterPluginManager(master_opts=__opts__, runners=__salt__).update(
        jid=__jid__  # pylint: disable=E0602
    )
