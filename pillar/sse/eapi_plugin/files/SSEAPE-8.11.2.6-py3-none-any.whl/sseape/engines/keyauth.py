# coding: utf-8
'''
The Key Auth engine

Manage keys for authenticating a salt-master to raas
'''

from __future__ import absolute_import
import base64
import datetime
import logging
import os
import shutil
import time

import salt.config
import salt.syspaths

from Cryptodome.PublicKey import RSA
from Cryptodome.Cipher import PKCS1_OAEP

import sseape.utils.client
from sseapiclient.exc import NotConnectable

__virtualname__ = 'keyauth'
log = logging.getLogger(__name__)


def __virtual__():
    if '__role' not in __opts__:
        return False, 'Unable to find out the role (master or minion)'
    if __opts__['__role'] != 'master':
        return (False,
                'The Key Auth engine is meant to run on the salt-master, '
                'not on {0}'.format(__opts__['__role']))
    if 'sseapi_password' in __opts__:
        return False, 'Master key authentication disabled: sseapi_password is set'
    if 'sseapi_pubkey_path' not in __opts__:
        return False, 'Master key authentication disabled: sseapi_pubkey_path is not set'
    return True


class KeyAuthEngine:

    def __init__(self, opts=None, raas_client=None):
        self.opts = opts
        self.raas_client = raas_client
        self.pubkey_path = opts['sseapi_pubkey_path']
        self.shared_jwt = sseape.utils.client.SharedJWT(self.opts)
        self.engine_interval = opts.get('sseapi_key_check', 15)
        self.last_key_test = 0
        self.key_test_interval = opts.get('sseapi_key_test', 300)
        self.key_rotation_interval = opts.get('sseapi_key_rotation', 24 * 3600)

    def request_master_key(self):
        '''
        Request a new authentication key from SSE
        '''
        log.info('%s engine: requesting a new SSE auth key', __virtualname__)
        try:
            self.raas_client.init_xsrf()
            body = {
                'resource': 'master',
                'method': 'request_master_key',
                'kwarg': {
                    'master_id': self.opts['id'],
                }
            }
            response = self.raas_client.fetch('/rpc', method='POST', body=body, retry_on_auth_failure=False)
        except Exception as exc:  # pylint: disable=broad-except
            log.error('%s engine: SSE auth key request failed: %s', __virtualname__, exc)
            return

        if 'pubkey' in response['ret'] and 'fingerprint' in response['ret']:
            log.info('%s engine: SSE auth key retrieved, writing to %s', __virtualname__, self.pubkey_path)
            orig_mask = os.umask(0o177)
            with open(self.pubkey_path, 'w') as fh:
                fh.write(response['ret']['pubkey'])
            os.umask(orig_mask)
            log.info('%s engine: SSE auth key fingerprint: %s', __virtualname__, response['ret']['fingerprint'])
        else:
            log.error('%s engine: SSE auth key request failed: pubkey missing from return: %s',
                      __virtualname__, response['ret'])

    def rotate_master_key(self):
        '''
        Rotate the SSE authentication key
        '''
        log.info('%s engine: rotating SSE auth key: %s', __virtualname__, self.pubkey_path)
        try:
            self.raas_client.init_xsrf()
            body = {
                'resource': 'master',
                'method': 'rotate_master_key',
                'kwarg': {
                    'master_id': self.opts['id'],
                }
            }
            response = self.raas_client.fetch('/rpc', method='POST', body=body, retry_on_auth_failure=False)
        except Exception as exc:  # pylint: disable=broad-except
            log.error('%s engine: SSE auth key rotation failed: %s', __virtualname__, exc)
            return

        if 'pubkey' in response['ret'] and 'fingerprint' in response['ret']:
            log.info('%s engine: SSE auth key retrieved, writing to %s', __virtualname__, self.pubkey_path)
            orig_mask = os.umask(0o177)
            new_key_path = self.pubkey_path + '.new'
            with open(new_key_path, 'w') as fh:
                fh.write(response['ret']['pubkey'])
            shutil.move(new_key_path, self.pubkey_path)
            os.umask(orig_mask)
            log.info('%s engine: SSE auth key fingerprint: %s', __virtualname__, response['ret']['fingerprint'])
            self.shared_jwt.remove()
        else:
            log.error('%s engine: SSE auth key rotation failed: pubkey missing from return: %s',
                      __virtualname__, response['ret'])

    def encrypt_message(self, data):
        '''
        Encrypt a message to send to SSE
        '''
        data = self.raas_client.json_dumps(data).encode()
        if hasattr(RSA, 'load_pub_key'):
            pubkey = RSA.load_pub_key(self.pubkey_path)
            emsg = pubkey.public_encrypt(data, RSA.pkcs1_oaep_padding)
        else:
            with open(self.pubkey_path, 'r') as fh:
                if hasattr(RSA, 'import_key'):
                    pubkey = RSA.import_key(fh.read())
                else:
                    pubkey = RSA.importKey(fh.read())

                cipher = PKCS1_OAEP.new(pubkey)
                emsg = cipher.encrypt(data)

        return base64.b64encode(emsg).decode()

    def get_master_jwt(self, test=False, init_xsrf=False):
        '''
        Get a jwt from SSE
        '''
        if init_xsrf:
            self.raas_client.init_xsrf()

        try:
            data = {
                'created': datetime.datetime.utcnow().isoformat() + 'Z',
                'master_id': self.opts['id'],
            }
            emsg = self.encrypt_message(data)
        except Exception as exc:  # pylint: disable=broad-except
            log.error('%s engine: encryption failed: %s', __virtualname__, exc)
            return None

        body = {
            'resource': 'master',
            'method': 'get_master_jwt',
            'kwarg': {
                'master_id': self.opts['id'],
                'encrypted_message': emsg,
                'test': test,
            }
        }
        response = self.raas_client.fetch('/rpc', method='POST', body=body, retry_on_auth_failure=False)
        return response

    def start(self):
        '''
        Engine main loop
        '''
        while True:
            log.info('%s engine: starting iteration', __virtualname__)

            if self.raas_client is None:
                try:
                    pillar = sseape.utils.client.get_pillar(
                        runners=__runners__,
                        opts=self.opts
                    )
                    self.raas_client = sseape.utils.client.make_http_client(opts=self.opts, pillar=pillar)
                except NotConnectable as exc:
                    log.debug('%s engine: could not connect to SSE server: %s', __virtualname__, exc)
                    time.sleep(self.engine_interval)
                    continue

            start = time.time()

            try:
                self.encrypt_message({})
            except Exception as exc:  # pylint: disable=broad-except
                log.debug('%s engine: %s: pubkey check failed: %s', __virtualname__, self.pubkey_path, exc)
                if self.shared_jwt.get():
                    # We still have a jwt, so ask raas to rotate the key to
                    # avoid the need for a human to accept the new key
                    self.rotate_master_key()
                else:
                    # No usable key and no jwt, so request a new auth key
                    self.request_master_key()

                # See if we have a usable key now. If not, skip the rest of the
                # iteration.
                try:
                    self.encrypt_message({})
                except Exception as exc:  # pylint: disable=broad-except
                    log.debug('%s engine: sleeping for %.1f seconds', __virtualname__, self.engine_interval)
                    time.sleep(self.engine_interval)
                    continue

            try:
                response = None
                if self.shared_jwt.get():
                    # Periodically check that the key is still valid according to raas
                    if start - self.last_key_test >= self.key_test_interval:
                        response = self.get_master_jwt(test=True, init_xsrf=True)
                        self.last_key_test = start
                else:
                    # If we don't have a jwt, get one
                    response = self.get_master_jwt(test=False, init_xsrf=True)
                if response is not None:
                    if response.get('error'):
                        log.info('%s engine: failed to get jwt: removing invalid SSE auth key: %s',
                                    __virtualname__, response['error'])
                        os.remove(self.pubkey_path)
                    elif response.get('ret'):
                        ret = response['ret']
                        if ret.get('state') == 'pending':
                            log.info('%s engine: waiting for SSE auth key to be accepted', __virtualname__)
                        elif ret.get('state') == 'accepted':
                            log.debug('%s engine: SSE auth key verified', __virtualname__)
                            if ret.get('jwt'):
                                self.shared_jwt.set(ret['jwt'])
                        key_stat = os.stat(self.pubkey_path)
                        if start - key_stat.st_mtime > self.key_rotation_interval:
                            self.rotate_master_key()
            except OSError as exc:
                log.error('%s engine: failed to save jwt: %s', __virtualname__, exc)
            except NotConnectable as exc:
                log.info('%s engine: failed to get jwt: %s', __virtualname__, exc)
            except Exception as exc:  # pylint: disable=broad-except
                log.error('%s engine: iteration interrupted with exception: %s',
                          __virtualname__, exc, exc_info=True)

            duration = time.time() - start
            # If the iteration ran longer than the interval, sleep a little anyway
            stime = self.engine_interval - duration
            if stime < 0:
                log.warning('%s engine: iteration time (%.1fs) exceeded interval (%.1fs)',
                            __virtualname__, duration, self.engine_interval)
                stime = min(5, self.engine_interval / 5)

            # Sleep before the next iteration.
            log.info('%s engine: sleeping for %.1f seconds', __virtualname__, stime)
            time.sleep(stime)


def start(raas_client=None):
    '''
    Start the engine
    '''
    opts = globals().get('__opts__')
    if opts is None:
        opts = salt.config.master_config(os.path.join(salt.syspaths.CONFIG_DIR, 'master'))

    KeyAuthEngine(opts, raas_client).start()
