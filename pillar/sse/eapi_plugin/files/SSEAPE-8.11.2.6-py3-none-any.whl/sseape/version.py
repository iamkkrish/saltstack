# coding: utf-8

import re

try:
    from sseape._buildinfo import BUILDINFO
except ImportError:
    import sseape.buildinfo
    BUILDINFO = sseape.buildinfo.get_buildinfo()


# Remove leading 'v' from version number tag
match = re.match('^v([0-9]+.*$)', BUILDINFO["git_describe"])
if match:
    __version__ = match.group(1)
else:
    __version__ = BUILDINFO["git_describe"] or "unknown"

del match, re
