# -*- coding: utf-8 -*-
"""
RaaS external pillar
"""

# Copyright (C) 2020 SaltStack, Inc.
#
# This file is licensed only for use with SaltStack's Enterprise software
# product and may not be used for any other purpose without prior written
# authorization from SaltStack, Inc.  The license terms governing your use of
# Salt Stack Enterprise also govern your use of this file. See license terms at
# https://www.saltstack.com/terms/


# Import Python libs
from __future__ import absolute_import
import logging

# Import Salt libs
import salt.utils.minions
from salt.exceptions import CommandExecutionError
from salt.serializers import DeserializationError, SerializationError

# Import 3rd-party libs
from sseapiclient.exc import NotConnectable, RPCError

# Import SSEAPE libs
from sseape.utils.client import make_api_client

log = logging.getLogger(__name__)

__virtualname__ = "sseapi"


def __virtual__():
    if "__role" not in __opts__:
        return False, "Unable to find out the role(master or minion)"
    if __opts__["__role"] == "minion" and "_ssh_version" not in __opts__:
        return (
            False,
            "The SSEApi pillar is meant to run on the salt-master, "
            "not on {0}".format(__opts__["__role"]),
        )
    return True


def get_client(pillar=None):
    if "sseapi_client" not in __context__:
        __context__["sseapi_client"] = make_api_client(__opts__, pillar=pillar)
    return __context__["sseapi_client"]


def _get_target_groups(pillar=None):
    """
    Get target groups from local cache or from raas
    """
    # Look in local cache first
    try:
        ret = __salt__["sseapi_local_cache.get_many"](cache="tgt", keypat="%")
        targets = [salt.serializers.msgpack.deserialize(x[1]) for x in ret]
    except (CommandExecutionError, DeserializationError) as exc:
        log.info("Failed to get target groups from local cache: %s", str(exc))
        targets = []

    # Get target groups from raas if necessary
    if not targets:
        log.debug("Get target groups from sseapi_server")
        page = 0
        while True:
            try:
                ret = (
                    get_client(pillar=pillar)
                    .api.tgt.get_target_group(page=page, limit=500)
                    .ret
                )
                if ret["results"]:
                    targets.extend(ret["results"])
                    page += 1
                else:
                    break
            except (NotConnectable, RPCError) as exc:
                log.error("Failed to get target groups: %s", str(exc))
                targets = []
                break

        # Save to local cache
        if targets:
            try:
                items = []
                for idx, tgt in enumerate(targets):
                    key = "tgt-{}".format(idx)
                    value = salt.serializers.msgpack.serialize(
                        tgt
                    )  # pylint: disable=assignment-from-no-return
                    items.append((key, value))
                __salt__["sseapi_local_cache.set_many"](cache="tgt", items=items)
                log.debug("Cached %s target groups", len(targets))
            except (CommandExecutionError, SerializationError) as exc:
                log.error(
                    "Failed to save %d target groups to local cache: %s",
                    len(targets),
                    str(exc),
                )

    return targets


def _refresh_pillar_cache(pillar=None):
    """
    Update the local cache of pillar data
    """
    pillar_returns = []
    client = get_client(pillar=pillar)
    page = 0
    while True:
        try:
            ret = client.api.pillar.get_pillars(page=page, limit=100).ret
            if ret["results"]:
                pillar_returns.extend(ret["results"])
                page += 1
            else:
                break

        except (NotConnectable, RPCError) as exc:
            log.error("Failed to get pillars: %s", str(exc))
            pillar_returns = {}
            return

    if pillar_returns:
        try:
            items = [
                (
                    x["uuid"],
                    salt.serializers.msgpack.serialize(
                        {
                            "name": x["name"],
                            "pillar": x["pillar"],
                            "pillar_type": x["pillar_type"],
                        }
                    ),
                )
                for x in pillar_returns
            ]
            if items:
                __salt__["sseapi_local_cache.set_many"](
                    cache="pillar", items=items, encrypt=True
                )
                log.debug("Cached %s pillars", len(items))
        except (CommandExecutionError, SerializationError) as exc:
            log.error(
                "Failed to save %s pillars to local cache: %s", len(items), str(exc)
            )


def _get_cached_pillars():
    """
    Get cached pillar data keyed by uuid
    """
    cached_pillar = {}
    try:
        ret = __salt__["sseapi_local_cache.get_many"](
            cache="pillar", keypat="%", decrypt=True
        )
        cached_pillar = {x[0]: salt.serializers.msgpack.deserialize(x[1]) for x in ret}
    except (CommandExecutionError, DeserializationError) as exc:
        log.info("Failed to get pillar from local cache: %s", str(exc))
    return cached_pillar


def _get_pillars_by_uuid(pillar_uuids, pillar=None):
    """
    Get the pillars matching a list of uuids. They should all exist since they
    are attached to target groups. The return payload is a composite dict of
    all matching pillars.
    """
    cached_pillar = _get_cached_pillars()
    if not all(u in cached_pillar for u in pillar_uuids):
        _refresh_pillar_cache(pillar=pillar)
        cached_pillar = _get_cached_pillars()

    pillar_dict = {}
    for pillar_uuid in pillar_uuids:
        this_pillar = cached_pillar.get(pillar_uuid, None)
        if this_pillar:
            pillar_dict.update(this_pillar["pillar"])
    return pillar_dict


def _get_minion_pillar_uuids(targets, minion_id):
    """
    Get pillar uuids from target groups that match a minion
    """
    minion_pillar_uuids = set()
    master_id = __opts__["id"]
    cluster_id = __opts__.get("sseapi_cluster_id")
    for target in targets:
        target_id = target.get("name") or target.get("uuid")
        log.debug("Checking target %s: %s", target_id, target)
        # Skip the target if there are no pillars associated with it
        pillar_uuids = target.get("pillars")
        if not pillar_uuids:
            log.debug("Target %s has no associated pillars", target_id)
            continue
        master_tgt = (
            target["tgt"].get("*")
            or target["tgt"].get(master_id)
            or target["tgt"].get(cluster_id)
        )
        if not master_tgt:
            log.debug("Target %s is not assigned to master %s", target_id, master_id)
            continue
        tgt_type = master_tgt.get("tgt_type", "glob")
        tgt = master_tgt.get("tgt")
        log.debug(
            "Check if minion %s matches target %s, tgt_type %s",
            minion_id,
            tgt,
            tgt_type,
        )
        ckminions = salt.utils.minions.CkMinions(__opts__)
        match = ckminions.check_minions(tgt, tgt_type)
        if isinstance(match, dict):
            # Salt > v2017.7.x
            # https://github.com/saltstack/salt/pull/42915
            match = match["minions"]
        if minion_id in match:
            log.debug("Minion %s found in match", minion_id)
            minion_pillar_uuids |= set(pillar_uuids)
        else:
            log.debug("Minion %s not found in match", minion_id)
    log.debug("Minion %s: %s pillars", minion_id, len(minion_pillar_uuids))
    return minion_pillar_uuids


def ext_pillar(minion_id, pillar, *args, **kwargs):  # pylint: disable=unused-argument
    """
    Get pillar data from RaaS. Note that this function is called once for each
    minion that fetches its pillar data.
    """
    # We require the CSP_AUTH_TOKEN pillar to instantiate sseapiclient,
    # but cannot access another pillar's value from current pillar.
    # Hence, disabled for salt-masters configured to connect to SSC on cloud.
    # This will also stop log files getting filled with http 403/307 errors.
    #    if __opts__.get('sseapi_csp_pillar'):
    #        return {}
    targets = _get_target_groups(pillar=pillar)
    pillar_uuids = _get_minion_pillar_uuids(targets, minion_id)

    pillar_to_merge = _get_pillars_by_uuid(pillar_uuids, pillar=pillar)
    return pillar_to_merge
